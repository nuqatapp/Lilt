import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Rect, Line, Text as SvgText, Path, Circle } from 'react-native-svg';
import { useDatabase } from '../database/DatabaseContext';
import { DEFAULT_HABITS } from '../constants/habits';
import { COLORS, CHART_PALETTE } from '../constants/theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// Date range helpers
function getWeekRange(date) {
  const d = new Date(date);
  const day = d.getDay();
  const start = new Date(d);
  start.setDate(d.getDate() - day);
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  end.setHours(23, 59, 59, 999);
  return { start, end };
}

function getMonthRange(date) {
  const d = new Date(date);
  const start = new Date(d.getFullYear(), d.getMonth(), 1);
  const end = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999);
  return { start, end };
}

function getDayRange(date) {
  const d = new Date(date);
  const start = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
  const end = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
  return { start, end };
}

function formatDateRange(range, start) {
  const opts = { month: 'short', day: 'numeric' };
  if (range === 'day') return start.toLocaleDateString([], { ...opts, weekday: 'short' });
  if (range === 'week') {
    const { start: ws, end: we } = getWeekRange(start);
    return `${ws.toLocaleDateString([], opts)} - ${we.toLocaleDateString([], opts)}`;
  }
  if (range === 'month') return start.toLocaleDateString([], { month: 'long', year: 'numeric' });
  return '';
}

function getHabitInfo(activityId) {
  return DEFAULT_HABITS.find((h) => h.id === activityId) || {
    id: activityId,
    label: activityId.replace(/_/g, ' ').replace('custom ', ''),
    icon: 'circle-outline',
    color: COLORS.teal,
  };
}

// ─── Bar Chart Component ───
function BarChart({ data, width = SCREEN_WIDTH - 80 }) {
  if (!data || data.length === 0) {
    return (
      <View style={styles.emptyChart}>
        <MaterialCommunityIcons name="chart-bar" size={32} color={COLORS.border} />
        <Text style={styles.emptyText}>No data yet</Text>
      </View>
    );
  }

  const maxVal = Math.max(...data.map((d) => d.count), 1);
  const chartHeight = 140;
  const barWidth = Math.min(48, (width - 40) / data.length - 12);
  const totalBarsWidth = data.length * (barWidth + 12);
  const startX = (width - totalBarsWidth) / 2 + 6;

  return (
    <Svg width={width} height={chartHeight + 40}>
      {/* Grid lines */}
      {[0, 0.5, 1].map((frac, i) => (
        <Line
          key={i}
          x1={0}
          y1={chartHeight * (1 - frac) + 10}
          x2={width}
          y2={chartHeight * (1 - frac) + 10}
          stroke={COLORS.border}
          strokeWidth={0.5}
          strokeDasharray="4,4"
        />
      ))}
      {/* Bars */}
      {data.map((item, i) => {
        const barH = (item.count / maxVal) * (chartHeight - 10);
        const x = startX + i * (barWidth + 12);
        const y = chartHeight - barH + 10;
        const color = CHART_PALETTE[i % CHART_PALETTE.length];
        return (
          <React.Fragment key={item.activity_id}>
            <Rect x={x} y={y} width={barWidth} height={barH} rx={6} fill={color} opacity={0.85} />
            <SvgText
              x={x + barWidth / 2}
              y={y - 6}
              fontSize={12}
              fontWeight="600"
              fill={COLORS.textPrimary}
              textAnchor="middle"
            >
              {item.count}
            </SvgText>
            <SvgText
              x={x + barWidth / 2}
              y={chartHeight + 28}
              fontSize={9}
              fill={COLORS.textSecondary}
              textAnchor="middle"
            >
              {getHabitInfo(item.activity_id).label.slice(0, 8)}
            </SvgText>
          </React.Fragment>
        );
      })}
    </Svg>
  );
}

// ─── Mini Line Chart Component ───
function LineChart({ datasets, labels, width = SCREEN_WIDTH / 2 - 50 }) {
  const chartH = 80;
  const colors = [COLORS.chartRose, COLORS.chartTeal, COLORS.chartGreen];

  if (!datasets || datasets.length === 0) {
    return (
      <View style={[styles.emptyChart, { height: chartH }]}>
        <Text style={styles.emptyText}>No data</Text>
      </View>
    );
  }

  const allVals = datasets.flat();
  const maxVal = Math.max(...allVals, 1);
  const stepX = datasets[0]?.length > 1 ? (width - 20) / (datasets[0].length - 1) : width / 2;
  const dayLabels = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <Svg width={width} height={chartH + 20}>
      {datasets.map((data, di) => {
        if (data.length < 2) return null;
        const points = data.map((val, i) => ({
          x: 10 + i * stepX,
          y: chartH - (val / maxVal) * (chartH - 15) + 5,
        }));
        const pathD = points.map((p, i) => (i === 0 ? `M${p.x},${p.y}` : `L${p.x},${p.y}`)).join(' ');
        return (
          <React.Fragment key={di}>
            <Path d={pathD} stroke={colors[di % colors.length]} strokeWidth={2} fill="none" opacity={0.8} />
            {points.map((p, i) => (
              <Circle key={i} cx={p.x} cy={p.y} r={2.5} fill={colors[di % colors.length]} />
            ))}
          </React.Fragment>
        );
      })}
      {dayLabels.map((label, i) => (
        <SvgText
          key={i}
          x={10 + i * stepX}
          y={chartH + 16}
          fontSize={9}
          fill={COLORS.textMuted}
          textAnchor="middle"
        >
          {label}
        </SvgText>
      ))}
    </Svg>
  );
}

// ─── Dashboard Screen ───
export default function DashboardScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { getLogs, getFrequencyCounts, getDailyCounts, isReady } = useDatabase();

  const [rangeType, setRangeType] = useState('week'); // day, week, month
  const [currentDate, setCurrentDate] = useState(new Date());
  const [frequencyData, setFrequencyData] = useState([]);
  const [recentLogs, setRecentLogs] = useState([]);
  const [insightData, setInsightData] = useState({ sugar: [], bathroom: [] });

  const getRange = useCallback(() => {
    if (rangeType === 'day') return getDayRange(currentDate);
    if (rangeType === 'week') return getWeekRange(currentDate);
    if (rangeType === 'month') return getMonthRange(currentDate);
    return getWeekRange(currentDate);
  }, [rangeType, currentDate]);

  // Load data when range changes
  useEffect(() => {
    if (isReady) loadData();
  }, [isReady, rangeType, currentDate]);

  const loadData = async () => {
    const { start, end } = getRange();
    const startISO = start.toISOString();
    const endISO = end.toISOString();

    // Frequency counts
    const freq = await getFrequencyCounts(startISO, endISO);
    setFrequencyData(freq.slice(0, 5)); // top 5

    // Recent logs
    const logs = await getLogs(startISO, endISO);
    setRecentLogs(logs.slice(0, 20));

    // Insight data (sugar + bathroom daily)
    const sugarDaily = await getDailyCounts('eating', startISO, endISO);
    const bathroomDaily = await getDailyCounts('bathroom', startISO, endISO);

    // Fill in days for the week
    if (rangeType === 'week') {
      const { start: ws } = getWeekRange(currentDate);
      const sugarArr = [];
      const bathArr = [];
      for (let i = 0; i < 7; i++) {
        const d = new Date(ws);
        d.setDate(ws.getDate() + i);
        const dateStr = d.toISOString().split('T')[0];
        const s = sugarDaily.find((r) => r.date === dateStr);
        const b = bathroomDaily.find((r) => r.date === dateStr);
        sugarArr.push(s ? s.count : 0);
        bathArr.push(b ? b.count : 0);
      }
      setInsightData({ sugar: sugarArr, bathroom: bathArr });
    } else {
      setInsightData({
        sugar: sugarDaily.map((r) => r.count),
        bathroom: bathroomDaily.map((r) => r.count),
      });
    }
  };

  // Navigate date range
  const navigateRange = (direction) => {
    const d = new Date(currentDate);
    if (rangeType === 'day') d.setDate(d.getDate() + direction);
    if (rangeType === 'week') d.setDate(d.getDate() + direction * 7);
    if (rangeType === 'month') d.setMonth(d.getMonth() + direction);
    setCurrentDate(d);
  };

  const formatTime = (isoString) => {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.headerArea}>
        <Text style={styles.appTitle}>
          Trace: <Text style={styles.appTitleLight}>Simple Habits</Text>
        </Text>
        <View style={styles.tabRow}>
          <TouchableOpacity style={styles.tab} onPress={() => navigation.navigate('LogActivity')}>
            <Text style={styles.tabTextInactive}>Log Activity</Text>
          </TouchableOpacity>
          <LinearGradient
            colors={[COLORS.rose, COLORS.roseLight]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={[styles.tab, styles.tabActive]}
          >
            <Text style={styles.tabTextActive}>Dashboard</Text>
          </LinearGradient>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Time Range Selector */}
        <View style={styles.timeRow}>
          <View style={styles.timeSelector}>
            <Text style={styles.timeLabel}>Time:</Text>
            <TouchableOpacity onPress={() => navigateRange(-1)} style={styles.navArrow}>
              <MaterialCommunityIcons name="chevron-left" size={20} color={COLORS.textSecondary} />
            </TouchableOpacity>
            <Text style={styles.timeValue}>{formatDateRange(rangeType, currentDate)}</Text>
            <TouchableOpacity onPress={() => navigateRange(1)} style={styles.navArrow}>
              <MaterialCommunityIcons name="chevron-right" size={20} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </View>
          <View style={styles.rangeTabs}>
            {['day', 'week', 'month'].map((r) => (
              <TouchableOpacity
                key={r}
                style={[styles.rangeTab, rangeType === r && styles.rangeTabActive]}
                onPress={() => setRangeType(r)}
              >
                <Text style={[styles.rangeTabText, rangeType === r && styles.rangeTabTextActive]}>
                  {r.charAt(0).toUpperCase() + r.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Top Row: Frequency + Insights */}
        <View style={styles.chartsRow}>
          {/* Frequency Bar Chart */}
          <View style={[styles.card, styles.chartCard]}>
            <Text style={styles.cardTitle}>Frequency Overview</Text>
            <Text style={styles.cardSubtitle}>(Top Habits)</Text>
            <BarChart data={frequencyData} width={SCREEN_WIDTH / 2 - 30} />
          </View>

          {/* Specific Insights */}
          <View style={[styles.card, styles.chartCard]}>
            <Text style={styles.cardTitle}>Specific Insights</Text>
            <View style={styles.legendRow}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: COLORS.chartRose }]} />
                <Text style={styles.legendText}>Eating</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: COLORS.chartTeal }]} />
                <Text style={styles.legendText}>Bathroom</Text>
              </View>
            </View>
            <LineChart
              datasets={[insightData.sugar, insightData.bathroom]}
              width={SCREEN_WIDTH / 2 - 50}
            />
          </View>
        </View>

        {/* Detailed Logs */}
        <View style={[styles.card, styles.logsCard]}>
          <Text style={styles.cardTitle}>Detailed Logs</Text>

          {recentLogs.length === 0 ? (
            <View style={styles.emptyLogs}>
              <MaterialCommunityIcons name="clipboard-text-outline" size={36} color={COLORS.border} />
              <Text style={styles.emptyText}>No logs for this period</Text>
              <Text style={styles.emptySubText}>Start logging activities to see them here</Text>
            </View>
          ) : (
            recentLogs.map((log, index) => {
              const habit = getHabitInfo(log.activity_id);
              const isFreeText = log.activity_id === 'free_text';
              return (
                <View key={log.id || index} style={[styles.logRow, index > 0 && styles.logRowBorder]}>
                  <Text style={styles.logTime}>{formatTime(log.timestamp)}</Text>
                  <View style={[styles.logIcon, { backgroundColor: (isFreeText ? COLORS.teal : habit.color) + '15' }]}>
                    <MaterialCommunityIcons
                      name={isFreeText ? 'note-text-outline' : habit.icon}
                      size={18}
                      color={isFreeText ? COLORS.teal : habit.color}
                    />
                  </View>
                  <View style={styles.logInfo}>
                    <Text style={styles.logLabel}>
                      {isFreeText ? 'Free Text' : habit.label}
                    </Text>
                    {log.sub_category ? (
                      <Text style={styles.logSub}>{log.sub_category.replace(/_/g, ' ')}</Text>
                    ) : null}
                    {log.notes ? (
                      <Text style={styles.logNotes} numberOfLines={2}>
                        {isFreeText ? log.notes : `Notes: ${log.notes}`}
                      </Text>
                    ) : null}
                  </View>
                </View>
              );
            })
          )}
        </View>

        {/* Dashboard Settings hint */}
        <View style={[styles.card, styles.settingsCard]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardTitle}>Dashboard Settings</Text>
            <Text style={styles.settingsDesc}>
              Customize which high-level habits appear as graphs.
            </Text>
          </View>
          <MaterialCommunityIcons name="cog" size={28} color={COLORS.textMuted} />
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgMain,
  },
  headerArea: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 12,
  },
  appTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  appTitleLight: {
    fontWeight: '400',
    color: COLORS.textSecondary,
  },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabActive: {
    borderRadius: 11,
  },
  tabTextActive: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.textWhite,
  },
  tabTextInactive: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.textMuted,
  },
  scrollContent: {
    paddingHorizontal: 14,
    paddingTop: 4,
  },
  // Time selector
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingHorizontal: 2,
  },
  timeSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  timeLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  timeValue: {
    fontSize: 13,
    fontWeight: '500',
    color: COLORS.textPrimary,
    minWidth: 90,
    textAlign: 'center',
  },
  navArrow: {
    padding: 2,
  },
  rangeTabs: {
    flexDirection: 'row',
    gap: 4,
  },
  rangeTab: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  rangeTabActive: {
    backgroundColor: COLORS.teal + '20',
  },
  rangeTabText: {
    fontSize: 13,
    color: COLORS.textMuted,
    fontWeight: '500',
  },
  rangeTabTextActive: {
    color: COLORS.teal,
    fontWeight: '700',
    textDecorationLine: 'underline',
  },
  // Charts row
  chartsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 12,
  },
  card: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 3,
    elevation: 1,
  },
  chartCard: {
    flex: 1,
    overflow: 'hidden',
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 2,
  },
  cardSubtitle: {
    fontSize: 11,
    color: COLORS.textMuted,
    marginBottom: 8,
  },
  // Legend
  legendRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 6,
    marginTop: 2,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendText: {
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  // Logs
  logsCard: {
    marginBottom: 12,
  },
  logRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    gap: 10,
  },
  logRowBorder: {
    borderTopWidth: 1,
    borderTopColor: COLORS.border + '80',
  },
  logTime: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textMuted,
    width: 65,
  },
  logIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logInfo: {
    flex: 1,
  },
  logLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  logSub: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textTransform: 'capitalize',
  },
  logNotes: {
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  // Settings card
  settingsCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  settingsDesc: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
    lineHeight: 17,
  },
  // Empty states
  emptyChart: {
    height: 120,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  emptyLogs: {
    alignItems: 'center',
    paddingVertical: 28,
    gap: 6,
  },
  emptyText: {
    fontSize: 13,
    color: COLORS.textMuted,
  },
  emptySubText: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
});
