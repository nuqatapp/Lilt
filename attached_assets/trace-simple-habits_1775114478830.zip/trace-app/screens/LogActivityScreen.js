import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useDatabase } from '../database/DatabaseContext';
import { DEFAULT_HABITS } from '../constants/habits';
import { COLORS } from '../constants/theme';
import HabitButton from '../components/HabitButton';
import SubCategoryModal from '../components/SubCategoryModal';
import AddCustomHabitModal from '../components/AddCustomHabitModal';
import Toast from '../components/Toast';

export default function LogActivityScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { logActivity, logFreeText, addCustomHabit, getCustomHabits, isReady } = useDatabase();

  const [allHabits, setAllHabits] = useState(DEFAULT_HABITS);
  const [noteText, setNoteText] = useState('');
  const [selectedHabit, setSelectedHabit] = useState(null);
  const [showSubModal, setShowSubModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: '', icon: '', color: '' });
  const [lastLogTime, setLastLogTime] = useState(null);

  // Load custom habits
  useEffect(() => {
    if (isReady) {
      loadCustomHabits();
    }
  }, [isReady]);

  const loadCustomHabits = async () => {
    const custom = await getCustomHabits();
    setAllHabits([...DEFAULT_HABITS, ...custom]);
  };

  const showToast = (message, icon, color) => {
    setToast({ visible: true, message, icon, color });
  };

  // Tap to log instantly
  const handleTap = useCallback(
    async (habit) => {
      const result = await logActivity(habit.id);
      if (result) {
        setLastLogTime(new Date());
        showToast(`${habit.label} logged!`, habit.icon, habit.color);
      }
    },
    [logActivity]
  );

  // Long press to show sub-categories
  const handleLongPress = useCallback((habit) => {
    setSelectedHabit(habit);
    setShowSubModal(true);
  }, []);

  // Select sub-category
  const handleSubSelect = useCallback(
    async (habit, subCat) => {
      setShowSubModal(false);
      const subLabel = subCat ? subCat.id : '';
      const result = await logActivity(habit.id, subLabel);
      if (result) {
        setLastLogTime(new Date());
        const detail = subCat ? ` → ${subCat.label}` : '';
        showToast(`${habit.label}${detail} logged!`, habit.icon, habit.color);
      }
    },
    [logActivity]
  );

  // Submit free text note
  const handleSubmitNote = useCallback(async () => {
    if (!noteText.trim()) return;
    const result = await logFreeText(noteText.trim());
    if (result) {
      setLastLogTime(new Date());
      showToast('Note saved!', 'note-text', COLORS.teal);
      setNoteText('');
    }
  }, [noteText, logFreeText]);

  // Add custom habit
  const handleAddCustom = useCallback(
    async (habit) => {
      const result = await addCustomHabit(habit);
      if (result) {
        setShowAddModal(false);
        loadCustomHabits();
        showToast(`${habit.label} added!`, habit.icon, habit.color);
      }
    },
    [addCustomHabit]
  );

  const formatLogTime = () => {
    if (!lastLogTime) return '';
    return `Log at: ${lastLogTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}, ${lastLogTime.toLocaleDateString([], { month: 'short', day: 'numeric' })}`;
  };

  const renderHabitItem = ({ item }) => (
    <HabitButton
      habit={item}
      onTap={handleTap}
      onLongPress={handleLongPress}
    />
  );

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Header */}
        <View style={styles.headerArea}>
          <Text style={styles.appTitle}>
            Trace: <Text style={styles.appTitleLight}>Simple Habits</Text>
          </Text>
          <View style={styles.tabRow}>
            <LinearGradient
              colors={[COLORS.tealDark, COLORS.teal]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.tab, styles.tabActive]}
            >
              <Text style={styles.tabTextActive}>Log Activity</Text>
            </LinearGradient>
            <TouchableOpacity
              style={styles.tab}
              onPress={() => navigation.navigate('Dashboard')}
            >
              <Text style={styles.tabTextInactive}>Dashboard</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Habit Grid */}
        <FlatList
          data={allHabits}
          renderItem={renderHabitItem}
          keyExtractor={(item) => item.id}
          numColumns={4}
          contentContainerStyle={styles.gridContent}
          columnWrapperStyle={styles.gridRow}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={
            <View style={styles.footer}>
              {/* Notes Input */}
              <View style={styles.notesSection}>
                <Text style={styles.notesTitle}>Notes / Free Text</Text>
                <View style={styles.notesRow}>
                  <TextInput
                    style={styles.notesInput}
                    placeholder="Add extra details..."
                    placeholderTextColor={COLORS.textMuted}
                    value={noteText}
                    onChangeText={setNoteText}
                    onSubmitEditing={handleSubmitNote}
                    returnKeyType="done"
                  />
                  <TouchableOpacity
                    style={[styles.logBtn, !noteText.trim() && styles.logBtnDisabled]}
                    onPress={handleSubmitNote}
                    disabled={!noteText.trim()}
                  >
                    <Text style={styles.logBtnText}>Log</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Timestamp */}
              {lastLogTime && (
                <View style={styles.timestampRow}>
                  <MaterialCommunityIcons name="clock-outline" size={14} color={COLORS.textMuted} />
                  <Text style={styles.timestampText}>{formatLogTime()}</Text>
                </View>
              )}

              {/* Add Custom Habit */}
              <TouchableOpacity
                style={styles.addCustomBtn}
                onPress={() => setShowAddModal(true)}
              >
                <MaterialCommunityIcons name="plus-circle" size={20} color={COLORS.teal} />
                <Text style={styles.addCustomText}>Add Custom Habit</Text>
              </TouchableOpacity>

              {/* Tap hint */}
              <Text style={styles.hint}>
                * Tap to log instantly. Long-press for details. Free text captured with date and time.
              </Text>
            </View>
          }
        />

        {/* Toast */}
        <Toast
          visible={toast.visible}
          message={toast.message}
          icon={toast.icon}
          color={toast.color}
          onHide={() => setToast({ ...toast, visible: false })}
        />

        {/* Sub-category Modal */}
        <SubCategoryModal
          visible={showSubModal}
          habit={selectedHabit}
          onSelect={handleSubSelect}
          onClose={() => setShowSubModal(false)}
        />

        {/* Add Custom Habit Modal */}
        <AddCustomHabitModal
          visible={showAddModal}
          onAdd={handleAddCustom}
          onClose={() => setShowAddModal(false)}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgMain,
  },
  headerArea: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 12,
  },
  appTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  appTitleLight: {
    fontWeight: '400',
    color: COLORS.textSecondary,
  },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabActive: {
    borderRadius: 11,
  },
  tabTextActive: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.textWhite,
  },
  tabTextInactive: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.textMuted,
  },
  gridContent: {
    paddingHorizontal: 8,
    paddingTop: 8,
  },
  gridRow: {
    justifyContent: 'flex-start',
    paddingHorizontal: 4,
  },
  footer: {
    paddingHorizontal: 12,
    paddingTop: 8,
    paddingBottom: 20,
  },
  notesSection: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 10,
  },
  notesTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 10,
  },
  notesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  notesInput: {
    flex: 1,
    backgroundColor: COLORS.bgInput,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: COLORS.textPrimary,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  logBtn: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 10,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderWidth: 1.5,
    borderColor: COLORS.teal,
  },
  logBtnDisabled: {
    borderColor: COLORS.border,
    opacity: 0.5,
  },
  logBtnText: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.teal,
  },
  timestampRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 4,
    marginBottom: 8,
  },
  timestampText: {
    fontSize: 12,
    color: COLORS.textMuted,
  },
  addCustomBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
  },
  addCustomText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.teal,
  },
  hint: {
    fontSize: 11,
    color: COLORS.textMuted,
    textAlign: 'center',
    lineHeight: 16,
    paddingHorizontal: 8,
  },
});
