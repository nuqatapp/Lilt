// Colors extracted from the wireframe
export const COLORS = {
  // Primary palette
  teal: '#4A7C7E',
  tealLight: '#6B9E9F',
  tealDark: '#3A6365',
  rose: '#C4908A',
  roseLight: '#D4A8A3',
  roseDark: '#A87670',

  // Backgrounds
  bgMain: '#F5F2EE',
  bgCard: '#FFFFFF',
  bgInput: '#F0EDE9',

  // Text
  textPrimary: '#2C2C2C',
  textSecondary: '#5A5A5A',
  textMuted: '#8A8A8A',
  textWhite: '#FFFFFF',

  // Chart colors
  chartTeal: '#4A7C7E',
  chartGreen: '#7BAE7F',
  chartRose: '#C4908A',
  chartPeach: '#D4B8A0',
  chartLavender: '#9B8EC4',

  // UI
  border: '#E0DCD7',
  shadow: '#00000015',
  overlay: '#00000060',
  white: '#FFFFFF',
};

// Header gradient
export const HEADER_GRADIENT = [COLORS.tealDark, COLORS.teal, COLORS.rose, COLORS.roseLight];

// Bar chart palette
export const CHART_PALETTE = [
  COLORS.chartTeal,
  COLORS.chartGreen,
  COLORS.chartRose,
  COLORS.chartPeach,
  COLORS.chartLavender,
];
