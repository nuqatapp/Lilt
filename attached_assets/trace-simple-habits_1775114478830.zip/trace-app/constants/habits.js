// Default habit definitions matching the wireframe
// Using MaterialCommunityIcons names

export const DEFAULT_HABITS = [
  {
    id: 'shower',
    label: 'Shower',
    icon: 'shower-head',
    color: '#6B9E9F',
    subCategories: [],
  },
  {
    id: 'exercise',
    label: 'Exercise',
    icon: 'run-fast',
    color: '#7BAE7F',
    subCategories: [
      { id: 'heavy', label: 'Heavy', icon: 'weight-lifter' },
      { id: 'light', label: 'Light', icon: 'human-handsup' },
      { id: 'cardio', label: 'Cardio', icon: 'heart-pulse' },
    ],
  },
  {
    id: 'bathroom',
    label: 'Bathroom',
    icon: 'toilet',
    color: '#9B8EC4',
    subCategories: [],
  },
  {
    id: 'eating',
    label: 'Eating',
    icon: 'silverware-fork-knife',
    color: '#C4908A',
    subCategories: [
      { id: 'breakfast', label: 'Breakfast', icon: 'coffee' },
      { id: 'main_meal', label: 'Main Meal', icon: 'food' },
      { id: 'sugar', label: 'Sugar', icon: 'candy-outline' },
      { id: 'hydration', label: 'Hydration', icon: 'water' },
    ],
  },
  {
    id: 'walking',
    label: 'Walking',
    icon: 'shoe-sneaker',
    color: '#D4B8A0',
    subCategories: [],
  },
  {
    id: 'cleaning',
    label: 'Cleaning',
    icon: 'broom',
    color: '#6B9E9F',
    subCategories: [],
  },
  {
    id: 'sleeping',
    label: 'Sleeping',
    icon: 'sleep',
    color: '#4A7C7E',
    subCategories: [],
  },
  {
    id: 'reading',
    label: 'Reading',
    icon: 'book-open-variant',
    color: '#7BAE7F',
    subCategories: [],
  },
  {
    id: 'work',
    label: 'Work',
    icon: 'laptop',
    color: '#8A8A8A',
    subCategories: [],
  },
  {
    id: 'stretching',
    label: 'Stretching',
    icon: 'human-handsup',
    color: '#C4908A',
    subCategories: [],
  },
];
