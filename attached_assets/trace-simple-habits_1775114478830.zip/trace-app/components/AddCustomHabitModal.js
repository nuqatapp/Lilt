import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Modal,
  StyleSheet,
  ScrollView,
  Pressable,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';

const ICON_OPTIONS = [
  'meditation', 'yoga', 'bicycle', 'pill', 'glass-wine', 'music',
  'phone', 'cart', 'car', 'airplane', 'camera', 'palette',
  'gamepad-variant', 'dumbbell', 'pray', 'food-apple', 'tea',
  'tooth', 'doctor', 'flower', 'tree', 'dog', 'cat', 'fish',
];

const COLOR_OPTIONS = [
  '#4A7C7E', '#7BAE7F', '#C4908A', '#D4B8A0', '#9B8EC4',
  '#E8A87C', '#85C1E9', '#82E0AA', '#F0B27A', '#BB8FCE',
];

export default function AddCustomHabitModal({ visible, onAdd, onClose }) {
  const [label, setLabel] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('meditation');
  const [selectedColor, setSelectedColor] = useState(COLOR_OPTIONS[0]);

  const handleAdd = () => {
    if (!label.trim()) return;
    const id = 'custom_' + label.toLowerCase().replace(/\s+/g, '_') + '_' + Date.now();
    onAdd?.({
      id,
      label: label.trim(),
      icon: selectedIcon,
      color: selectedColor,
      subCategories: [],
      isCustom: true,
    });
    setLabel('');
    setSelectedIcon('meditation');
    setSelectedColor(COLOR_OPTIONS[0]);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation()}>
          <View style={styles.handleBar} />
          <Text style={styles.title}>Add Custom Habit</Text>

          <TextInput
            style={styles.input}
            placeholder="Habit name..."
            placeholderTextColor={COLORS.textMuted}
            value={label}
            onChangeText={setLabel}
            maxLength={20}
          />

          <Text style={styles.sectionLabel}>Choose Icon</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.iconRow}>
            {ICON_OPTIONS.map((icon) => (
              <TouchableOpacity
                key={icon}
                style={[styles.iconOption, selectedIcon === icon && { borderColor: selectedColor, borderWidth: 2 }]}
                onPress={() => setSelectedIcon(icon)}
              >
                <MaterialCommunityIcons name={icon} size={24} color={selectedIcon === icon ? selectedColor : COLORS.textMuted} />
              </TouchableOpacity>
            ))}
          </ScrollView>

          <Text style={styles.sectionLabel}>Choose Color</Text>
          <View style={styles.colorRow}>
            {COLOR_OPTIONS.map((color) => (
              <TouchableOpacity
                key={color}
                style={[
                  styles.colorOption,
                  { backgroundColor: color },
                  selectedColor === color && styles.colorSelected,
                ]}
                onPress={() => setSelectedColor(color)}
              />
            ))}
          </View>

          {/* Preview */}
          <View style={styles.preview}>
            <View style={[styles.previewIcon, { backgroundColor: selectedColor + '18' }]}>
              <MaterialCommunityIcons name={selectedIcon} size={32} color={selectedColor} />
            </View>
            <Text style={styles.previewLabel}>{label || 'Habit Name'}</Text>
          </View>

          <TouchableOpacity
            style={[styles.addBtn, !label.trim() && styles.addBtnDisabled]}
            onPress={handleAdd}
            disabled={!label.trim()}
          >
            <Text style={styles.addBtnText}>Add Habit</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: COLORS.overlay,
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: COLORS.bgMain,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  handleBar: {
    width: 40,
    height: 4,
    backgroundColor: COLORS.border,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 12,
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 16,
  },
  input: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: COLORS.textPrimary,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 16,
  },
  sectionLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 8,
  },
  iconRow: {
    marginBottom: 16,
  },
  iconOption: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: COLORS.bgCard,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  colorRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  colorOption: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  colorSelected: {
    borderWidth: 3,
    borderColor: COLORS.textPrimary,
  },
  preview: {
    alignItems: 'center',
    paddingVertical: 16,
    marginBottom: 12,
  },
  previewIcon: {
    width: 64,
    height: 64,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginTop: 8,
  },
  addBtn: {
    backgroundColor: COLORS.teal,
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
  },
  addBtnDisabled: {
    opacity: 0.4,
  },
  addBtnText: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.textWhite,
  },
});
