import React, { useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { COLORS } from '../constants/theme';

export default function HabitButton({ habit, onTap, onLongPress, isCompact = false }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Animated.spring(scaleAnim, {
      toValue: 0.92,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  };

  const handleTap = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onTap?.(habit);
  };

  const handleLongPress = () => {
    if (habit.subCategories && habit.subCategories.length > 0) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      onLongPress?.(habit);
    } else {
      // No sub-categories, just log it
      handleTap();
    }
  };

  const size = isCompact ? 70 : 85;
  const iconSize = isCompact ? 28 : 36;
  const fontSize = isCompact ? 10 : 12;

  return (
    <Animated.View style={[styles.wrapper, { transform: [{ scale: scaleAnim }] }]}>
      <TouchableOpacity
        style={[styles.button, { width: size, height: size }]}
        onPress={handleTap}
        onLongPress={handleLongPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        delayLongPress={400}
        activeOpacity={0.9}
      >
        <View style={[styles.iconCircle, { backgroundColor: habit.color + '18' }]}>
          <MaterialCommunityIcons
            name={habit.icon}
            size={iconSize}
            color={habit.color || COLORS.teal}
          />
        </View>
        {habit.subCategories?.length > 0 && (
          <View style={styles.longPressBadge}>
            <Text style={styles.longPressText}>⋯</Text>
          </View>
        )}
      </TouchableOpacity>
      <Text style={[styles.label, { fontSize }]} numberOfLines={1}>
        {habit.label}
      </Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'center',
    margin: 6,
  },
  button: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 3,
    elevation: 2,
  },
  iconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    marginTop: 5,
    fontWeight: '500',
    color: COLORS.textPrimary,
    textAlign: 'center',
  },
  longPressBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: COLORS.teal + '30',
    alignItems: 'center',
    justifyContent: 'center',
  },
  longPressText: {
    fontSize: 10,
    color: COLORS.teal,
    fontWeight: '700',
    lineHeight: 12,
  },
});
