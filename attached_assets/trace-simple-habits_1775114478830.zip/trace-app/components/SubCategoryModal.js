import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  StyleSheet,
  Pressable,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { COLORS } from '../constants/theme';

export default function SubCategoryModal({ visible, habit, onSelect, onClose }) {
  if (!habit) return null;

  const handleSelect = (subCat) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onSelect?.(habit, subCat);
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation()}>
          {/* Handle bar */}
          <View style={styles.handleBar} />

          {/* Header */}
          <View style={styles.header}>
            <View style={[styles.headerIcon, { backgroundColor: habit.color + '20' }]}>
              <MaterialCommunityIcons
                name={habit.icon}
                size={28}
                color={habit.color || COLORS.teal}
              />
            </View>
            <Text style={styles.headerTitle}>{habit.label}</Text>
            <Text style={styles.headerSub}>long-press</Text>
          </View>

          {/* Sub-category grid */}
          <View style={styles.grid}>
            {habit.subCategories?.map((sub) => (
              <TouchableOpacity
                key={sub.id}
                style={styles.subButton}
                onPress={() => handleSelect(sub)}
                activeOpacity={0.7}
              >
                <View style={[styles.subIcon, { backgroundColor: habit.color + '15' }]}>
                  <MaterialCommunityIcons
                    name={sub.icon}
                    size={26}
                    color={habit.color || COLORS.teal}
                  />
                </View>
                <Text style={styles.subLabel}>{sub.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Quick log without sub-category */}
          <TouchableOpacity
            style={styles.quickLog}
            onPress={() => handleSelect(null)}
            activeOpacity={0.7}
          >
            <Text style={styles.quickLogText}>Log without detail</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: COLORS.overlay,
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: COLORS.bgMain,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingBottom: 40,
    minHeight: 250,
  },
  handleBar: {
    width: 40,
    height: 4,
    backgroundColor: COLORS.border,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 12,
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginLeft: 12,
    flex: 1,
  },
  headerSub: {
    fontSize: 11,
    color: COLORS.textMuted,
    fontStyle: 'italic',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    gap: 12,
  },
  subButton: {
    alignItems: 'center',
    width: 80,
    paddingVertical: 8,
  },
  subIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.bgCard,
  },
  subLabel: {
    fontSize: 12,
    fontWeight: '500',
    color: COLORS.textPrimary,
    marginTop: 6,
    textAlign: 'center',
  },
  quickLog: {
    marginTop: 20,
    paddingVertical: 12,
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  quickLogText: {
    fontSize: 14,
    color: COLORS.textMuted,
  },
});
