# Trace: Simple Habits

A clean, minimalist activity logging app for iOS. Track habits with a single tap, view analytics on a dashboard.

## Features

- **Instant Logging**: Tap any habit icon to log it immediately with timestamp
- **Sub-categories**: Long-press Exercise (Heavy/Light/Cardio) or Eating (Breakfast/Main Meal/Sugar/Hydration) for detail
- **Free Text Notes**: Type and save notes with auto-timestamp
- **Custom Habits**: Add your own habits with custom icons and colors
- **Dashboard Analytics**: Frequency bar charts, trend line charts, detailed log history
- **Date Range Filters**: Day / Week / Month views with navigation
- **Local SQLite Storage**: All data stays on-device via expo-sqlite

## Folder Structure

```
trace-app/
├── App.js                          # Entry point with tab navigation
├── app.json                        # Expo configuration
├── package.json                    # Dependencies
├── babel.config.js                 # Babel config with Reanimated plugin
├── constants/
│   ├── habits.js                   # Default habit definitions (icons, sub-categories)
│   └── theme.js                    # Color palette, gradients
├── database/
│   └── DatabaseContext.js          # SQLite database (CRUD, analytics queries)
├── screens/
│   ├── LogActivityScreen.js        # Main logging screen with habit grid
│   └── DashboardScreen.js          # Analytics dashboard with charts
├── components/
│   ├── ScreenHeader.js             # Gradient header with tab switcher
│   ├── HabitButton.js              # Animated tap/long-press habit icon
│   ├── SubCategoryModal.js         # Bottom sheet for sub-options
│   ├── AddCustomHabitModal.js      # Modal to create custom habits
│   └── Toast.js                    # Animated confirmation toast
└── assets/                         # App icons, splash screen
```

## Setup in Replit

1. Create a new **React Native / Expo** Repl
2. Replace the project files with this folder structure
3. Run `npm install` in the Shell
4. Run `npx expo start` to launch

## Data Schema

Each activity log is stored as:
```json
{
  "id": 1,
  "activity_id": "exercise",
  "sub_category": "cardio",
  "timestamp": "2026-04-02T09:15:00.000Z",
  "notes": "",
  "created_at": "2026-04-02T09:15:00.000Z"
}
```

## Bundle Identifier

`app.nuqat.trace` — ready for your Apple Developer account.
