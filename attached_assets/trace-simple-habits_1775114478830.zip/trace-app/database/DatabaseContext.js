import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import * as SQLite from 'expo-sqlite';

const DatabaseContext = createContext(null);

export function DatabaseProvider({ children }) {
  const [db, setDb] = useState(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    async function initDB() {
      try {
        const database = await SQLite.openDatabaseAsync('trace_habits.db');

        await database.execAsync(`
          CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            activity_id TEXT NOT NULL,
            sub_category TEXT DEFAULT '',
            timestamp TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
          );
        `);

        await database.execAsync(`
          CREATE TABLE IF NOT EXISTS custom_habits (
            id TEXT PRIMARY KEY,
            label TEXT NOT NULL,
            icon TEXT NOT NULL,
            color TEXT DEFAULT '#6B9E9F',
            sub_categories TEXT DEFAULT '[]',
            created_at TEXT DEFAULT (datetime('now'))
          );
        `);

        setDb(database);
        setIsReady(true);
      } catch (error) {
        console.error('Database init error:', error);
      }
    }

    initDB();
  }, []);

  // Log an activity
  const logActivity = useCallback(
    async (activityId, subCategory = '', notes = '') => {
      if (!db) return null;
      const timestamp = new Date().toISOString();
      try {
        const result = await db.runAsync(
          'INSERT INTO activity_logs (activity_id, sub_category, timestamp, notes) VALUES (?, ?, ?, ?)',
          [activityId, subCategory, timestamp, notes]
        );
        return { id: result.lastInsertRowId, activity_id: activityId, sub_category: subCategory, timestamp, notes };
      } catch (error) {
        console.error('Log activity error:', error);
        return null;
      }
    },
    [db]
  );

  // Log free text note
  const logFreeText = useCallback(
    async (text) => {
      if (!db) return null;
      const timestamp = new Date().toISOString();
      try {
        const result = await db.runAsync(
          'INSERT INTO activity_logs (activity_id, sub_category, timestamp, notes) VALUES (?, ?, ?, ?)',
          ['free_text', '', timestamp, text]
        );
        return { id: result.lastInsertRowId, activity_id: 'free_text', sub_category: '', timestamp, notes: text };
      } catch (error) {
        console.error('Log free text error:', error);
        return null;
      }
    },
    [db]
  );

  // Get logs for a date range
  const getLogs = useCallback(
    async (startDate, endDate) => {
      if (!db) return [];
      try {
        const rows = await db.getAllAsync(
          'SELECT * FROM activity_logs WHERE timestamp >= ? AND timestamp <= ? ORDER BY timestamp DESC',
          [startDate, endDate]
        );
        return rows;
      } catch (error) {
        console.error('Get logs error:', error);
        return [];
      }
    },
    [db]
  );

  // Get all logs (most recent first)
  const getAllLogs = useCallback(
    async (limit = 50) => {
      if (!db) return [];
      try {
        const rows = await db.getAllAsync(
          'SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT ?',
          [limit]
        );
        return rows;
      } catch (error) {
        console.error('Get all logs error:', error);
        return [];
      }
    },
    [db]
  );

  // Get frequency counts for a date range
  const getFrequencyCounts = useCallback(
    async (startDate, endDate) => {
      if (!db) return [];
      try {
        const rows = await db.getAllAsync(
          `SELECT activity_id, COUNT(*) as count 
           FROM activity_logs 
           WHERE timestamp >= ? AND timestamp <= ? AND activity_id != 'free_text'
           GROUP BY activity_id 
           ORDER BY count DESC`,
          [startDate, endDate]
        );
        return rows;
      } catch (error) {
        console.error('Get frequency error:', error);
        return [];
      }
    },
    [db]
  );

  // Get daily counts for a specific activity over a date range (for line charts)
  const getDailyCounts = useCallback(
    async (activityId, startDate, endDate) => {
      if (!db) return [];
      try {
        const rows = await db.getAllAsync(
          `SELECT DATE(timestamp) as date, COUNT(*) as count 
           FROM activity_logs 
           WHERE activity_id = ? AND timestamp >= ? AND timestamp <= ?
           GROUP BY DATE(timestamp) 
           ORDER BY date ASC`,
          [activityId, startDate, endDate]
        );
        return rows;
      } catch (error) {
        console.error('Get daily counts error:', error);
        return [];
      }
    },
    [db]
  );

  // Get sub-category breakdown
  const getSubCategoryBreakdown = useCallback(
    async (activityId, startDate, endDate) => {
      if (!db) return [];
      try {
        const rows = await db.getAllAsync(
          `SELECT sub_category, COUNT(*) as count 
           FROM activity_logs 
           WHERE activity_id = ? AND sub_category != '' AND timestamp >= ? AND timestamp <= ?
           GROUP BY sub_category 
           ORDER BY count DESC`,
          [activityId, startDate, endDate]
        );
        return rows;
      } catch (error) {
        console.error('Get sub-category breakdown error:', error);
        return [];
      }
    },
    [db]
  );

  // Add custom habit
  const addCustomHabit = useCallback(
    async (habit) => {
      if (!db) return null;
      try {
        await db.runAsync(
          'INSERT OR REPLACE INTO custom_habits (id, label, icon, color, sub_categories) VALUES (?, ?, ?, ?, ?)',
          [habit.id, habit.label, habit.icon, habit.color || '#6B9E9F', JSON.stringify(habit.subCategories || [])]
        );
        return habit;
      } catch (error) {
        console.error('Add custom habit error:', error);
        return null;
      }
    },
    [db]
  );

  // Get custom habits
  const getCustomHabits = useCallback(
    async () => {
      if (!db) return [];
      try {
        const rows = await db.getAllAsync('SELECT * FROM custom_habits ORDER BY created_at ASC');
        return rows.map((row) => ({
          id: row.id,
          label: row.label,
          icon: row.icon,
          color: row.color,
          subCategories: JSON.parse(row.sub_categories || '[]'),
          isCustom: true,
        }));
      } catch (error) {
        console.error('Get custom habits error:', error);
        return [];
      }
    },
    [db]
  );

  // Delete a log entry
  const deleteLog = useCallback(
    async (logId) => {
      if (!db) return false;
      try {
        await db.runAsync('DELETE FROM activity_logs WHERE id = ?', [logId]);
        return true;
      } catch (error) {
        console.error('Delete log error:', error);
        return false;
      }
    },
    [db]
  );

  const value = {
    db,
    isReady,
    logActivity,
    logFreeText,
    getLogs,
    getAllLogs,
    getFrequencyCounts,
    getDailyCounts,
    getSubCategoryBreakdown,
    addCustomHabit,
    getCustomHabits,
    deleteLog,
  };

  return <DatabaseContext.Provider value={value}>{children}</DatabaseContext.Provider>;
}

export function useDatabase() {
  const context = useContext(DatabaseContext);
  if (!context) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
}
